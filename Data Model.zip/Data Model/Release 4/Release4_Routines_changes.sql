-- Modifications to the procedures
DROP PROCEDURE IF EXISTS modify_task;
DROP PROCEDURE IF EXISTS get_task_list;
DROP PROCEDURE IF EXISTS create_task;
DROP PROCEDURE IF EXISTS assign_task;

DELIMITER $$

CREATE PROCEDURE assign_task
    (p_task_id                  INT
    ,p_assigned_to_person_id    INT
    ,p_username                 VARCHAR(30))
BEGIN

    DECLARE v_assigned_by_person_id INT;
    DECLARE v_assigned_to_name, v_assigned_by_name VARCHAR(160);

    -- capture the assigned by person id
    SELECT p.person_id, CONCAT(p.first_nm,' ',p.last_nm) full_nm
    INTO v_assigned_by_person_id, v_assigned_by_name
    FROM user_account ua
    JOIN person p
      ON p.person_id = ua.person_id
    WHERE user_nm = UCASE(p_username);
    
    -- Modified for Release 3 to handle cases where the new assignee is null
    IF p_assigned_to_person_id IS NULL THEN
        SET v_assigned_to_name = 'NULL';
    ELSE 
        SELECT CONCAT(p.first_nm,' ',p.last_nm) full_nm
        INTO v_assigned_to_name
        FROM person p
        WHERE p.person_id = p_assigned_to_person_id;
    END IF;
    
    -- Update the task to show the assignment
    UPDATE task
    SET assigned_to_person_id = p_assigned_to_person_id
       ,assigned_by_person_id = v_assigned_by_person_id
       ,last_updated_by_user_nm = p_username
       ,last_updated_dttm = CURRENT_TIMESTAMP
    WHERE task_id = p_task_id;
    
    -- log a comment with the assignment information
    CALL add_task_comment
        (p_task_id
        ,CONCAT('Task assigned to "',v_assigned_to_name,'" by "',v_assigned_by_name,'".')
        ,'Task Reassignment'
        ,p_username);

END$$

CREATE PROCEDURE create_task
    (p_parent_task_id INT
    ,p_priority_nr    INT
    ,p_short_title_tx VARCHAR(50)
    ,p_short_description_tx   VARCHAR(100)
    ,p_long_description_tx    VARCHAR(2000)
    ,p_deadline_dt            DATE
    ,p_estimated_completion_dt    DATE
    ,p_completion_dt              DATE
    ,p_recipient_person_id        INT
    ,p_assigned_organization_id   INT
    ,p_assigned_to_person_id      INT
    ,p_username                   VARCHAR(30))
BEGIN
    
    DECLARE v_task_id INT;
    
    -- Insert task
    INSERT INTO task
        (parent_task_id
        ,priority_nr
        ,short_title_tx
        ,short_description_tx
        ,long_description_tx
        ,deadline_dt
        ,estimated_completion_dt
        ,completion_dt
        ,recipient_person_id
        ,assigned_organization_id
        ,created_by_user_nm)
    VALUES 
        (p_parent_task_id
        ,p_priority_nr
        ,p_short_title_tx
        ,p_short_description_tx
        ,p_long_description_tx
        ,p_deadline_dt
        ,p_estimated_completion_dt
        ,p_completion_dt
        ,p_recipient_person_id
        ,p_assigned_organization_id
        ,p_username);
    
    SET v_task_id = LAST_INSERT_ID();
    
    -- Insert task comment
    CALL add_task_comment
        (v_task_id
        ,CONCAT('Task created by ',p_username)
        ,'Task Created'
        ,p_username);
        
    -- If the task is assigned
    IF p_assigned_to_person_id IS NOT NULL THEN
        -- Assign the task
        CALL assign_task(v_task_id
                        ,p_assigned_to_person_id
                        ,p_username);
    END IF; -- end if the task is assigned

END$$

CREATE PROCEDURE modify_task 
    (p_task_id                    INT
    ,p_parent_task_id             INT
    ,p_priority_nr                INT
    ,p_short_title_tx             VARCHAR(50)
    ,p_short_description_tx       VARCHAR(100)
    ,p_long_description_tx        VARCHAR(2000)
    ,p_deadline_dt                DATE
    ,p_estimated_completion_dt    DATE
    ,p_completion_dt              DATE
    ,p_recipient_person_id        INT
    ,p_assigned_organization_id   INT
    ,p_assigned_to_person_id      INT
    ,p_username                   VARCHAR(30))
BEGIN

    DECLARE v_curr_parent_task_id, v_curr_priority_nr, v_curr_recipient_person_id, v_curr_assigned_org_id, v_curr_assigned_person_id INT;
    DECLARE v_curr_short_title_tx, v_curr_parent_short_title_tx, v_new_parent_short_title_tx VARCHAR(50);
    DECLARE v_curr_short_desc_tx VARCHAR(100);
    DECLARE v_comment_tx VARCHAR(500);
    DECLARE v_curr_long_desc_tx VARCHAR(2000);
    DECLARE v_curr_deadline_dt, v_curr_est_completion_dt, v_curr_completion_dt DATE;
        
    -- Get the current values for comparison
    SELECT t.parent_task_id
          ,t.priority_nr
          ,t.short_title_tx
          ,t.short_description_tx
          ,t.long_description_tx
          ,DATE(t.deadline_dt) deadline_dt -- removing the time portion if present
          ,DATE(t.estimated_completion_dt) estimated_completion_dt -- removing the time portion if present
          ,DATE(t.completion_dt) completion_dt -- removing the time portion if present
          ,t.recipient_person_id
          ,t.assigned_organization_id
          ,t.assigned_to_person_id
          ,pt.short_title_tx 
    INTO v_curr_parent_task_id
        ,v_curr_priority_nr
        ,v_curr_short_title_tx
        ,v_curr_short_desc_tx
        ,v_curr_long_desc_tx
        ,v_curr_deadline_dt
        ,v_curr_est_completion_dt
        ,v_curr_completion_dt
        ,v_curr_recipient_person_id
        ,v_curr_assigned_org_id
        ,v_curr_assigned_person_id
        ,v_curr_parent_short_title_tx
    FROM task t
    LEFT JOIN task pt
      ON t.parent_task_id = pt.task_id
    WHERE t.task_id = p_task_id;


    -- If anything in the task changed, then update the task record
    IF IFNULL(v_curr_parent_task_id,-1) <> IFNULL(p_parent_task_id,-1) -- parent task
    OR v_curr_priority_nr <> p_priority_nr -- priority
    OR v_curr_short_title_tx <> p_short_title_tx -- short title
    OR v_curr_short_desc_tx <> p_short_description_tx -- short description
    OR IFNULL(v_curr_long_desc_tx,'') <> IFNULL(p_long_description_tx,'') -- long description
    OR IFNULL(v_curr_deadline_dt,STR_TO_DATE('1900-01-01','%Y-%m-%d')) <> IFNULL(p_deadline_dt,STR_TO_DATE('1900-01-01','%Y-%m-%d')) -- deadline date
    OR IFNULL(v_curr_est_completion_dt,STR_TO_DATE('1900-01-01','%Y-%m-%d')) <> IFNULL(p_estimated_completion_dt,STR_TO_DATE('1900-01-01','%Y-%m-%d')) -- estimated completion date
    OR IFNULL(v_curr_completion_dt,STR_TO_DATE('1900-01-01','%Y-%m-%d')) <> IFNULL(p_completion_dt,STR_TO_DATE('1900-01-01','%Y-%m-%d')) -- completion date
    OR IFNULL(v_curr_recipient_person_id,-1) <> IFNULL(p_recipient_person_id,-1) -- recipient
    OR IFNULL(v_curr_assigned_org_id,-1) <> IFNULL(p_assigned_organization_id,-1) -- assigned org
    OR IFNULL(v_curr_assigned_person_id,-1) <> IFNULL(p_assigned_to_person_id,-1) -- assigned person
    THEN
        -- Update the task table
        UPDATE task
        SET parent_task_id = p_parent_task_id
           ,priority_nr = p_priority_nr
           ,short_title_tx = p_short_title_tx
           ,short_description_tx = p_short_description_tx
           ,long_description_tx = p_long_description_tx
           ,deadline_dt = p_deadline_dt
           ,estimated_completion_dt = p_estimated_completion_dt
           ,completion_dt = p_completion_dt
           ,recipient_person_id = p_recipient_person_id
           ,assigned_organization_id = p_assigned_organization_id
           -- assigned person information is updated via a call to the assign_task() procedure
           ,last_updated_by_user_nm = p_username
           ,last_updated_dttm = CURRENT_TIMESTAMP()
        WHERE task_id = p_task_id;
              
        -- Log comments for changes
        -- If parent task changed
        IF IFNULL(v_curr_parent_task_id,-1) <> IFNULL(p_parent_task_id,-1) THEN
            
            SELECT short_title_tx
            INTO v_new_parent_short_title_tx
            FROM task
            WHERE task_id = p_parent_task_id;
            
            -- Insert a task comment
            CALL add_task_comment
                (p_task_id
                ,CONCAT('Parent Task changed from "',IFNULL(v_curr_parent_short_title_tx,'NULL'),'" to "',IFNULL(v_new_parent_short_title_tx,'NULL'),'".')
                ,'Task Changed'
                ,p_username);
            
        END IF; -- if parent task changed
        
        -- If priority changed
        IF v_curr_priority_nr <> p_priority_nr THEN

            -- Insert a task comment
            CALL add_task_comment
                (p_task_id
                ,CONCAT('Task Priority changed from "',v_curr_priority_nr,'" to "',p_priority_nr,'".')
                ,'Task Changed'
                ,p_username);
        
        END IF; -- If priority changed
        
        -- If short title changed
        IF v_curr_short_title_tx <> p_short_title_tx THEN
            
            -- Insert a task comment
            CALL add_task_comment
                (p_task_id
                ,CONCAT('Short Title changed from "',v_curr_short_title_tx,'" to "',p_short_title_tx,'".')
                ,'Task Changed'
                ,p_username);
            
        END IF; -- If short title changed

        -- If short description changed
        IF v_curr_short_desc_tx <> p_short_description_tx THEN
        
            -- Insert a task comment
            CALL add_task_comment
                (p_task_id
                ,CONCAT('Short Description changed from "',v_curr_short_desc_tx,'" to "',p_short_description_tx,'".')
                ,'Task Changed'
                ,p_username);
                        
        END IF; -- If short description changed
        
        -- If long description changed
        IF IFNULL(v_curr_long_desc_tx,'') <> IFNULL(p_long_description_tx,'') THEN
            
            -- Insert a task comment
            CALL add_task_comment
                (p_task_id
                ,CONCAT('Long Description changed from "',IFNULL(v_curr_long_desc_tx,'NULL'),'" to "',IFNULL(p_long_description_tx,'NULL'),'".')
                ,'Task Changed'
                ,p_username);
            
        END IF; -- If long description changed
        
        -- If Deadline changed
        IF IFNULL(v_curr_deadline_dt,STR_TO_DATE('1900-01-01','%Y-%m-%d')) <> IFNULL(p_deadline_dt,STR_TO_DATE('1900-01-01','%Y-%m-%d')) THEN
        
            -- Insert a task comment
            CALL add_task_comment
                (p_task_id
                ,CONCAT('Deadline Date changed from "',IFNULL(DATE_FORMAT(v_curr_deadline_dt,'%m/%d/%Y'),'NULL'),'" to "',IFNULL(DATE_FORMAT(p_deadline_dt,'%m/%d/%Y'),'NULL'),'".')
                ,'Task Changed'
                ,p_username);
                   
        END IF; -- If deadline changed
        
        -- If Estimated Completion Date changed
        IF IFNULL(v_curr_est_completion_dt,STR_TO_DATE('1900-01-01','%Y-%m-%d')) <> IFNULL(p_estimated_completion_dt,STR_TO_DATE('1900-01-01','%Y-%m-%d')) THEN
        
            -- Insert a task comment
            CALL add_task_comment
                (p_task_id
                ,CONCAT('Estimated Completion Date changed from "',IFNULL(DATE_FORMAT(v_curr_est_completion_dt,'%m/%d/%Y'),'NULL'),'" to "',IFNULL(DATE_FORMAT(p_estimated_completion_dt,'%m/%d/%Y'),'NULL'),'".')
                ,'Task Changed'
                ,p_username);   
        
        END IF; -- If estimated completion date changed
        
        -- If Completion Date changed
        IF IFNULL(v_curr_completion_dt,STR_TO_DATE('1900-01-01','%Y-%m-%d')) <> IFNULL(p_completion_dt,STR_TO_DATE('1900-01-01','%Y-%m-%d')) THEN
            
            -- Insert a task comment
            CALL add_task_comment
                (p_task_id
                ,CONCAT('Completion Date changed from "',IFNULL(DATE_FORMAT(v_curr_completion_dt,'%m/%d/%Y'),'NULL'),'" to "',IFNULL(DATE_FORMAT(p_completion_dt,'%m/%d/%Y'),'NULL'),'".')
                ,'Task Changed'
                ,p_username);
        
        END IF;
        
        -- If Recipient changed
        IF IFNULL(v_curr_recipient_person_id,-1) <> IFNULL(p_recipient_person_id,-1) THEN
        
            -- Build the comment text 
            SELECT CONCAT('Recipient changed from "'
                         ,CASE WHEN v_curr_recipient_person_id IS NULL
                               THEN 'NULL'
                               ELSE (SELECT CONCAT(first_nm,' ',last_nm) FROM person WHERE person_id = v_curr_recipient_person_id)
                          END
                         ,'" to "'
                         ,CASE WHEN p_recipient_person_id IS NULL
                               THEN 'NULL'
                               ELSE (SELECT CONCAT(first_nm,' ',last_nm) FROM person WHERE person_id = p_recipient_person_id)
                          END
                         ,'".')
            INTO v_comment_tx
            FROM dual;
        
            -- Insert a task comment
            CALL add_task_comment
                (p_task_id
                ,v_comment_tx
                ,'Task Changed'
                ,p_username);
        
        END IF; -- If recipient person changed
        
        -- If Assigned Org changed
        IF IFNULL(v_curr_assigned_org_id,-1) <> IFNULL(p_assigned_organization_id,-1) THEN
        
            -- Build the comment text
            SELECT CONCAT('Assigned Organization changed from "'
                         ,CASE WHEN v_curr_assigned_org_id IS NULL
                               THEN 'NULL'
                               ELSE (SELECT organization_short_title_tx FROM organization WHERE organization_id = v_curr_assigned_org_id)
                          END
                         ,'" to "'
                         ,CASE WHEN p_assigned_organization_id IS NULL
                               THEN 'NULL'
                               ELSE (SELECT organization_short_title_tx FROM organization WHERE organization_id = p_assigned_organization_id)
                          END
                         ,'".')
            INTO v_comment_tx
            FROM dual;
            
            -- Insert a task comment
            CALL add_task_comment
                (p_task_id
                ,v_comment_tx
                ,'Task Changed'
                ,p_username);
        
        END IF; -- If assigned org changed
        
        -- If Assigned Person changed
        IF IFNULL(v_curr_assigned_person_id,-1) <> IFNULL(p_assigned_to_person_id,-1) THEN
            
            -- Call assign_task to make the change to the assignment
            CALL assign_task(p_task_id, p_assigned_to_person_id, p_username);
            
        END IF;  -- If assigned person changed

    END IF; -- checking if anything changed

END$$


/*
-- PROCEDURE: get_task_list
-- DESCRIPTION: Starting point for getting the list of visible organizations
-- Accepts the user's user name as a parameter and builds the list of organizations he/she belongs to and the children of those organizations
-- USED BY: application to get the list of tasks the user can view
-- CHANGE LOG:
--  31-Mar-12 (BAL) Created procedure
*/
CREATE PROCEDURE get_task_list
    (p_username VARCHAR(30)
    ,p_org_id   INT
    ,p_assigned_to_id   INT)
BEGIN

    DECLARE v_person_id INT;

    -- Find the organizations this user can see
    CALL get_visible_orgs(p_username);

    -- Find the user's person id
    SELECT person_id
    INTO v_person_id
    FROM user_account
    WHERE user_nm = p_username;
    
    DROP TEMPORARY TABLE IF EXISTS __task_list1;
    DROP TEMPORARY TABLE IF EXISTS __task_list2;
    
    -- List of tasks created by this user, listing this user as recipient, or assigned to this user
    CREATE TEMPORARY TABLE __task_list1 AS
    SELECT t.*
          ,CASE -- Creator or organization leader
                WHEN t.created_by_user_nm = UCASE(p_username)
                  OR ol.organization_leader_in = 'Y'
                THEN 'Y'
                ELSE 'N'
           END full_access_in
          ,CASE -- Creator, organization leader, or recipient
                WHEN t.created_by_user_nm = UCASE(p_username)
                  OR ol.organization_leader_in = 'Y'
                  OR t.recipient_person_id = v_person_id
                THEN 'Y'
                ELSE 'N'
           END recipient_access_in
          ,CASE -- Creator, organization leader, or assignee
                WHEN t.created_by_user_nm = UCASE(p_username)
                  OR ol.organization_leader_in = 'Y'
                  OR t.assigned_to_person_id = v_person_id
                THEN 'Y'
                ELSE 'N'
           END assignee_access_in
          ,CASE -- Creator, organization leader, or assignee 
                WHEN t.created_by_user_nm = UCASE(p_username)
                  OR ol.organization_leader_in = 'Y'
                  OR t.assigned_to_person_id = v_person_id
                  OR ol.organization_id IS NOT NULL
                THEN 'Y'
                ELSE 'N'
           END assigned_group_access_in
    FROM task t
    LEFT JOIN task pt
      ON t.parent_task_id = pt.task_id
    LEFT JOIN __org_list ol
      ON t.assigned_organization_id = ol.organization_id
    WHERE IFNULL(p_assigned_to_id,IFNULL(t.assigned_to_person_id,-1)) = IFNULL(t.assigned_to_person_id,-1)
    AND IFNULL(p_org_id,IFNULL(t.assigned_organization_id,-1)) = IFNULL(t.assigned_organization_id,-1)
    AND (   t.created_by_user_nm = UCASE(p_username)
         OR t.recipient_person_id = v_person_id
         OR t.assigned_to_person_id = v_person_id)
    ;
    
    -- List of tasks assigned to this user's organizations
    CREATE TEMPORARY TABLE __task_list2 AS
    SELECT t.*
          ,CASE -- Creator or organization leader
                WHEN t.created_by_user_nm = UCASE(p_username)
                  OR ol.organization_leader_in = 'Y'
                THEN 'Y'
                ELSE 'N'
           END full_access_in
          ,CASE -- Creator, organization leader, or recipient
                WHEN t.created_by_user_nm = UCASE(p_username)
                  OR ol.organization_leader_in = 'Y'
                  OR t.recipient_person_id = v_person_id
                THEN 'Y'
                ELSE 'N'
           END recipient_access_in
          ,CASE -- Creator, organization leader, or assignee
                WHEN t.created_by_user_nm = UCASE(p_username)
                  OR ol.organization_leader_in = 'Y'
                  OR t.assigned_to_person_id = v_person_id
                THEN 'Y'
                ELSE 'N'
           END assignee_access_in
          ,'Y' assigned_group_access_in  -- this query only returns tasks assigned to the user's organizations
    FROM __org_list ol
    JOIN task t
      ON ol.organization_id = t.assigned_organization_id
    WHERE IFNULL(p_assigned_to_id,IFNULL(t.assigned_to_person_id,-1)) = IFNULL(t.assigned_to_person_id,-1)
    AND IFNULL(p_org_id,IFNULL(t.assigned_organization_id,-1)) = IFNULL(t.assigned_organization_id,-1);
    
    -- Select the final results
    SELECT pt.short_title_tx parent_short_title_tx
          ,tl1.*
    FROM __task_list1 tl1
    LEFT JOIN task pt
      ON tl1.parent_task_id = pt.task_id
    UNION
    SELECT pt.short_title_tx parent_short_title_tx
          ,tl2.* 
    FROM __task_list2 tl2
    LEFT JOIN task pt
      ON tl2.parent_task_id = pt.task_id;
             
END$$