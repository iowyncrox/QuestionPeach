USE task_manager;

DROP PROCEDURE IF EXISTS test;
DROP FUNCTION IF EXISTS check_login;
DROP PROCEDURE IF EXISTS assign_task;
DROP PROCEDURE IF EXISTS create_task;
DROP PROCEDURE IF EXISTS get_org_children;
DROP PROCEDURE IF EXISTS get_visible_orgs;
DROP PROCEDURE IF EXISTS get_assign_to_organizations;
DROP PROCEDURE IF EXISTS get_assign_to_people;
DROP PROCEDURE IF EXISTS get_task_list;

-- Change the delimiter to $$
DELIMITER $$

/*
-- PROCEDURE: test
-- DESCRIPTION: quick test procedure to create and use in conjunction with test_proc.php to prove that the 
-- procedures can be called from php pages
-- USED BY: testers
-- CHANGE LOG: 
--  30-Mar-12 (BAL) Created procedure
*/
CREATE PROCEDURE test 
    (id INT)
BEGIN
    SELECT * FROM organization
    WHERE organization_id = id;
END$$

/* 
-- FUNCTION: check_login
-- DESCRIPTION: determines if the username and password provided are valid
-- USED BY: application login page
-- CHANGE LOG:
--  30-Mar-12 (BAL) Created procedure
*/
CREATE FUNCTION check_login 
    (p_username VARCHAR(30)
    ,p_password VARCHAR(300))
RETURNS INT
BEGIN
    DECLARE retval INT;
    
    SELECT COUNT(1) ct
    INTO retval
    FROM user_account
    WHERE user_nm = UCASE(p_username)
    AND password_tx = md5(p_password)
    AND NOW() <= IFNULL(end_dt,NOW());

    RETURN retval;
    
END$$

/*
-- PROCEDURE: assign_task
-- DESCRIPTION: Updates the TASK table
-- Logs a TASK_COMMENT stating the task was reassigned
-- USED BY: application when a task assignment is changed
--          create_task procedure when a task is assigned at creation time
-- CHANGE LOG:
--  30-Mar-12 (BAL) Created procedure
*/
CREATE PROCEDURE assign_task
    (p_task_id  INT
    ,p_assigned_to_person_id    INT
    ,p_username VARCHAR(30))
BEGIN

    DECLARE v_assigned_by_person_id INT;
    DECLARE v_assigned_to_name, v_assigned_by_name VARCHAR(160);

    -- capture the assigned by person id
    SELECT p.person_id, CONCAT(p.first_nm,' ',p.last_nm) full_nm
    INTO v_assigned_by_person_id, v_assigned_by_name
    FROM user_account ua
    JOIN person p
      ON p.person_id = ua.person_id
    WHERE user_nm = UCASE(p_username);
    
    SELECT CONCAT(p.first_nm,' ',p.last_nm) full_nm
    INTO v_assigned_to_name
    FROM person p
    WHERE p.person_id = p_assigned_to_person_id;
    
    -- Update the task to show the assignment
    UPDATE task
    SET assigned_to_person_id = p_assigned_to_person_id
       ,assigned_by_person_id = v_assigned_by_person_id
       ,last_updated_by_user_nm = p_username
       ,last_updated_dttm = CURRENT_TIMESTAMP
    WHERE task_id = p_task_id;
    
    -- Sleep for a second because the current_timestamp gets truncated to the second and may cause primary key violation
    SELECT SLEEP(1);
    
    -- log a comment with the assignment information
    INSERT INTO task_comment
        (task_id
        ,comment_tx
        ,comment_type_tx
        ,created_by_user_nm)
    VALUES (p_task_id
           ,CONCAT('Task assigned to ',v_assigned_to_name,' by ',v_assigned_by_name)
           ,'Task Reassignment'
           ,p_username);

END$$

/*
-- PROCEDURE: create_task
-- DESCRIPTION: Inserts a new task
-- USED BY: application when a new task is saved
-- CHANGE LOG:
--  30-Mar-12 (BAL) Created procedure
*/
CREATE PROCEDURE create_task 
    (p_parent_task_id INT
    ,p_priority_nr    INT
    ,p_short_title_tx VARCHAR(50)
    ,p_short_description_tx   VARCHAR(100)
    ,p_long_description_tx    VARCHAR(2000)
    ,p_deadline_dt            DATE
    ,p_estimated_completion_dt    DATE
    ,p_completion_dt              DATE
    ,p_recipient_person_id        INT
    ,p_assigned_organization_id   INT
    ,p_assigned_to_person_id      INT
    ,p_username                   VARCHAR(30))
BEGIN
    
    DECLARE v_task_id INT;
    
    -- Insert task
    INSERT INTO task
        (parent_task_id
        ,priority_nr
        ,short_title_tx
        ,short_description_tx
        ,long_description_tx
        ,deadline_dt
        ,estimated_completion_dt
        ,completion_dt
        ,recipient_person_id
        ,assigned_organization_id
        ,created_by_user_nm)
    VALUES 
        (p_parent_task_id
        ,p_priority_nr
        ,p_short_title_tx
        ,p_short_description_tx
        ,p_long_description_tx
        ,p_deadline_dt
        ,p_estimated_completion_dt
        ,p_completion_dt
        ,p_recipient_person_id
        ,p_assigned_organization_id
        ,p_username);
    
    SET v_task_id = LAST_INSERT_ID();
    
    -- Insert task comment
    INSERT INTO task_comment
        (task_id
        ,comment_tx
        ,comment_type_tx
        ,created_by_user_nm)
    VALUES
        (v_task_id
        ,CONCAT('Task created by ',p_username)
        ,'Task Created'
        ,p_username);
        
    -- If the task is assigned
    IF p_assigned_to_person_id IS NOT NULL THEN
        -- Assign the task
        CALL assign_task(v_task_id
                        ,p_assigned_to_person_id
                        ,p_username);
    END IF; -- end if the task is assigned

END$$

/* 
-- PROCEDURE: get_org_children
-- DESCRIPTION: retrieves the children, children's children, etc. for the p_parent_org_id
--  Reference: http://jan.kneschke.de/projects/mysql/sp/
-- USED BY: get_visible_orgs
-- CHANGE LOG:
--  31-Mar-12 (BAL) Created procedure
*/
CREATE PROCEDURE get_org_children
    (p_parent_org_id   INT
    ,p_org_leader_in   CHAR(1))
BEGIN
    -- Declare variables
    -- Holds child's organization id
    DECLARE v_child_org_id INT;
    -- Indicates if there are no more records in the cursor
    DECLARE v_done INT DEFAULT 0;
    -- Cursor to find the child organizations to p_parent_org_id
    DECLARE org_curs CURSOR FOR 
        SELECT organization_id
        FROM organization
        WHERE parent_organization_id = p_parent_org_id;
    -- Handler to tell when no more records retrieved by cursor --> exit the loop
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = 1;
    
    -- Find child organizations for the p_org_id
    OPEN org_curs;
    
    -- Loop through records retrieved
    get_child_fetch_loop: LOOP
        FETCH org_curs INTO v_child_org_id;
        
        -- If the cursor retrieved nothing, v_done gets set to 1 by the handler
        IF v_done = 1 THEN
            LEAVE get_child_fetch_loop;
        END IF;
        
        -- Insert the child organization into the temporary table
        INSERT INTO __org_list_build VALUES (v_child_org_id, p_org_leader_in);
        
        -- Recursively call this procedure again for the child that is found
        CALL get_org_children(v_child_org_id, p_org_leader_in);
        
    END LOOP get_child_fetch_loop;
    
    -- Close the cursor
    CLOSE org_curs;
        
END$$

/*
-- PROCEDURE: get_visible_orgs
-- DESCRIPTION: Starting point for getting the list of visible organizations
-- Accepts the user's user name as a parameter and builds the list of organizations he/she belongs to and the children of those organizations
--  Reference: http://jan.kneschke.de/projects/mysql/sp/
-- USED BY: application to build the list of this user's organizations.
-- Call this procedure once for the user before calls to get_assign_to_orgs, get_assign_to_people, get_task_list 
-- It will build the list of organizations the given user can access.
-- CHANGE LOG:
--  31-Mar-12 (BAL) Created procedure
*/
CREATE PROCEDURE get_visible_orgs
    (p_username VARCHAR(30))
BEGIN

    -- Declare variables
    -- Holds organization id's
    DECLARE v_org_id INT;
    DECLARE v_org_leader_in CHAR(1);
    -- Indicates if there are no more records in the cursor
    DECLARE v_done INT DEFAULT 0; 
    -- Cursor to find the organizations this user belongs to
    DECLARE org_member_curs CURSOR FOR
        SELECT om.organization_id
              ,om.org_leader_in
        FROM user_account ua
        JOIN person p
          ON ua.person_id = p.person_id
        JOIN organization_member om
          ON p.person_id = om.person_id
        WHERE ua.user_nm = UCASE(p_username);
    -- Handler to tell when no more records retrieved by cursor --> exit the loop
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = 1;

    -- Create a temporary tables to store the org ids the user can access
    -- __org_list_build is the working copy
    -- __org_list is the final copy
    DROP TEMPORARY TABLE IF EXISTS __org_list_build;
    CREATE TEMPORARY TABLE __org_list_build
        (organization_id INT NOT NULL PRIMARY KEY
        ,organization_leader_in CHAR(1) NOT NULL DEFAULT 'N');
    DROP TEMPORARY TABLE IF EXISTS __org_list;
    CREATE TEMPORARY TABLE __org_list 
        (organization_id INT NOT NULL PRIMARY KEY
        ,organization_leader_in CHAR(1) NOT NULL DEFAULT 'N');
            
    -- Find organizations the user belongs to
    OPEN org_member_curs;
    
    -- Loop through organizations
    get_org_fetch_loop: LOOP
    
        FETCH org_member_curs INTO v_org_id, v_org_leader_in;
        
        -- If the cursor retrieved nothing, v_done gets set to 1 by the handler
        IF v_done = 1 THEN
            LEAVE get_org_fetch_loop;
        END IF;
        
        -- Insert the organization into the temporary table
        INSERT INTO __org_list_build VALUES (v_org_id, v_org_leader_in);

        -- Find children for these organizations
        CALL get_org_children(v_org_id, v_org_leader_in);
    
    -- End loop
    END LOOP get_org_fetch_loop;

    -- Close the cursor
    CLOSE org_member_curs;
    
    -- Insert into the final table
    INSERT INTO __org_list
    SELECT organization_id, MAX(organization_leader_in)
    FROM __org_list_build
    GROUP BY organization_id;
    
    -- Drop the interim table 
    DROP TEMPORARY TABLE IF EXISTS __org_list_build;
	
END$$

/*
-- PROCEDURE: get_assign_to_organizations
-- DESCRIPTION: Starting point for getting the list of visible organizations
-- Accepts the user's user name as a parameter and builds the list of organizations he/she belongs to and the children of those organizations
-- USED BY: application to get the drop-down list of organizations the user can view
-- CHANGE LOG:
--  31-Mar-12 (BAL) Created procedure
*/
CREATE PROCEDURE get_assign_to_organizations
    (p_username VARCHAR(30))
BEGIN

    -- Find the organizations this user can see
    CALL get_visible_orgs(p_username);
            
    -- Select the results
    SELECT DISTINCT 
           o.organization_id
          ,CASE WHEN po.organization_short_title_tx IS NULL
                THEN o.organization_short_title_tx
                ELSE CONCAT(po.organization_short_title_tx,' - ',o.organization_short_title_tx)
           END org_display
    FROM __org_list ol
    JOIN organization o
      ON ol.organization_id = o.organization_id
    LEFT JOIN organization po
      ON o.parent_organization_id = po.organization_id
    ORDER BY org_display;

END$$

/*
-- PROCEDURE: get_assign_to_people
-- DESCRIPTION: Starting point for getting the list of visible organizations
-- Accepts the user's user name as a parameter and builds the list of organizations he/she belongs to and the children of those organizations
-- USED BY: application to get the drop-down list of people the user can view
-- CHANGE LOG:
--  31-Mar-12 (BAL) Created procedure
*/
CREATE PROCEDURE get_assign_to_people
    (p_username VARCHAR(30)
    ,p_org_id   INT)
BEGIN
    
    -- Find the organizations this user can see
    CALL get_visible_orgs(p_username);
            
    -- Select the results
    SELECT DISTINCT p.person_id
          ,CONCAT(p.first_nm,' ',p.last_nm) person_nm
    FROM __org_list ol
    JOIN organization_member om
      ON ol.organization_id = om.organization_id
    JOIN person p
      ON om.person_id = p.person_id
    WHERE IFNULL(p_org_id,ol.organization_id) = ol.organization_id
    AND (-- Cannot assign to an organization leader unless this user is an organization leader
            ol.organization_leader_in = 'Y'
         OR om.org_leader_in <> 'Y')
    ORDER BY person_id;
    
END$$

/*
-- PROCEDURE: get_task_list
-- DESCRIPTION: Starting point for getting the list of visible organizations
-- Accepts the user's user name as a parameter and builds the list of organizations he/she belongs to and the children of those organizations
-- USED BY: application to get the list of tasks the user can view
-- CHANGE LOG:
--  31-Mar-12 (BAL) Created procedure
*/
CREATE PROCEDURE get_task_list
    (p_username VARCHAR(30)
    ,p_org_id   INT
    ,p_assigned_to_id   INT)
BEGIN

    DECLARE v_person_id INT;

    -- Find the organizations this user can see
    CALL get_visible_orgs(p_username);

    -- Find the user's person id
    SELECT person_id
    INTO v_person_id
    FROM user_account
    WHERE user_nm = p_username;
    
    DROP TEMPORARY TABLE IF EXISTS __task_list1;
    DROP TEMPORARY TABLE IF EXISTS __task_list2;
    
    -- List of tasks created by this user, listing this user as recipient, or assigned to this user
    CREATE TEMPORARY TABLE __task_list1 AS
    SELECT t.*
          ,CASE -- Creator or organization leader
                WHEN t.created_by_user_nm = UCASE(p_username)
                  OR ol.organization_leader_in = 'Y'
                THEN 'Y'
                ELSE 'N'
           END full_access_in
          ,CASE -- Creator, organization leader, or recipient
                WHEN t.created_by_user_nm = UCASE(p_username)
                  OR ol.organization_leader_in = 'Y'
                  OR t.recipient_person_id = v_person_id
                THEN 'Y'
                ELSE 'N'
           END recipient_access_in
          ,CASE -- Creator, organization leader, or assignee
                WHEN t.created_by_user_nm = UCASE(p_username)
                  OR ol.organization_leader_in = 'Y'
                  OR t.assigned_to_person_id = v_person_id
                THEN 'Y'
                ELSE 'N'
           END assignee_access_in
          ,CASE -- Creator, organization leader, or assignee 
                WHEN t.created_by_user_nm = UCASE(p_username)
                  OR ol.organization_leader_in = 'Y'
                  OR t.assigned_to_person_id = v_person_id
                  OR ol.organization_id IS NOT NULL
                THEN 'Y'
                ELSE 'N'
           END assigned_group_access_in
    FROM task t
    LEFT JOIN task pt
      ON t.parent_task_id = pt.task_id
    LEFT JOIN __org_list ol
      ON t.assigned_organization_id = ol.organization_id
    WHERE IFNULL(p_assigned_to_id,IFNULL(t.assigned_to_person_id,-1)) = IFNULL(t.assigned_to_person_id,-1)
    AND IFNULL(p_org_id,IFNULL(t.assigned_organization_id,-1)) = IFNULL(t.assigned_organization_id,-1)
    AND (   t.created_by_user_nm = UCASE(p_username)
         OR t.recipient_person_id = v_person_id
         OR t.assigned_to_person_id = v_person_id)
    ;
    
    -- List of tasks assigned to this user's organizations
    CREATE TEMPORARY TABLE __task_list2 AS
    SELECT t.*
          ,CASE -- Creator or organization leader
                WHEN t.created_by_user_nm = UCASE(p_username)
                  OR ol.organization_leader_in = 'Y'
                THEN 'Y'
                ELSE 'N'
           END full_access_in
          ,CASE -- Creator, organization leader, or recipient
                WHEN t.created_by_user_nm = UCASE(p_username)
                  OR ol.organization_leader_in = 'Y'
                  OR t.recipient_person_id = v_person_id
                THEN 'Y'
                ELSE 'N'
           END recipient_access_in
          ,CASE -- Creator, organization leader, or assignee
                WHEN t.created_by_user_nm = UCASE(p_username)
                  OR ol.organization_leader_in = 'Y'
                  OR t.assigned_to_person_id = v_person_id
                THEN 'Y'
                ELSE 'N'
           END assignee_access_in
          ,'Y' assigned_group_access_in  -- this query only returns tasks assigned to the user's organizations
    FROM __org_list ol
    JOIN task t
      ON ol.organization_id = t.assigned_organization_id;
    
    -- Select the final results
    SELECT pt.short_title_tx parent_short_title_tx
          ,tl1.*
    FROM __task_list1 tl1
    LEFT JOIN task pt
      ON tl1.parent_task_id = pt.task_id
    UNION
    SELECT pt.short_title_tx parent_short_title_tx
          ,tl2.* 
    FROM __task_list2 tl2
    LEFT JOIN task pt
      ON tl2.parent_task_id = pt.task_id;
             
END$$

-- Change the delimter back to ;
DELIMITER ;