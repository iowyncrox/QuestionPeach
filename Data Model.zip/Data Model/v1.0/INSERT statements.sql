-- Insert the initial user account "SYSTEM"
-- Since PERSON_ID is null, the trigger on USER_ACCOUNT will end-date the account
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('SYSTEM',md5('csci6442'),NULL,'question?','answer');

-- ORGANIZATION Data
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (NULL,'Database Systems II (CSCI 6442)','CSCI 6442','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (1,'CSCI 6442: System Engineering Team','System Engineering','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (1,'CSCI 6442: Data Modeling Team','Data Modeling','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (1,'CSCI 6442: User Interface Team (Flex)','UI Team','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (1,'CSCI 6442: Processing Team (PHP)','Processing Team','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (NULL,'That One Company','That One Co.','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (6,'Marketing Department','Marketing','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (6,'Sales Department','Sales','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (6,'Human Resources Department','HR','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (7,'District A Marketing','District A Marketing','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (7,'District B Marketing','District B Marketing','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (7,'District C Marketing','District C Marketing','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (8,'Region A Sales','Region A Sales','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (8,'Region B Sales','Region B Sales','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (9,'Position Classification','Classification','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (9,'Candidate Recruitment','Recruitment','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (9,'Human Resource Development (Training)','Training','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (10,'Public Relations','PR','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (11,'Public Relations','PR','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (12,'Public Relations','PR','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (10,'Product Services','Product Services','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (11,'Product Services','Product Services','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (12,'Product Services','Product Services','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (13,'District A1','District A1','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (13,'District A2','District A2','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (13,'District A3','District A3','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (14,'District B1','District B1','SYSTEM');
INSERT INTO ORGANIZATION (parent_ORGANIZATION_id, ORGANIZATION_nm, ORGANIZATION_short_title_tx, created_by_user_nm) VALUES (14,'District B2','District B2','SYSTEM');

-- PERSON Data
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Professor','Professor','professor@fake.com','202-555-0000','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','One','one@fake.com','703-555-0101','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Two','two@fake.com','703-555-0202','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Three','three@fake.com','301-555-0303','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Four','four@fake.com','703-555-0404','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Five','five@fake.com','301-555-0505','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Six','six@fake.com','202-555-0606','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Seven','seven@fake.com','202-555-0707','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Eight','eight@fake.com','703-555-0808','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Nine','nine@fake.com','571-555-0909','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Ten','ten@fake.com','202-555-1010','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Eleven','eleven@fake.com','202-555-1111','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Twelve','twelve@fake.com','703-555-1212','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Thirteen','thirteen@fake.com','703-555-1313','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Fourteen','fourteen@fake.com','301-555-1414','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Fifteen','fifteen@fake.com','301-555-1515','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Sixteen','sixteen@fake.com','571-555-1616','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Seventeen','seventeen@fake.com','571-555-1717','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Eighteen','eighteen@fake.com','571-555-1818','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Nineteen','nineteen@fake.com','703-555-1919','SYSTEM');
INSERT INTO PERSON (first_nm, last_nm, email_address_tx, phone_number_tx, created_by_user_nm) VALUES ('Student','Twenty','twenty@fake.com','202-555-2020','SYSTEM');

-- ORGANIZATION MEMBER Data
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (1,1,'Y','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (2,2,'Y','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (2,3,'N','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (2,4,'N','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (2,5,'N','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (3,6,'Y','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (3,7,'N','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (3,8,'N','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (4,9,'Y','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (4,10,'N','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (4,11,'N','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (4,12,'N','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (4,13,'N','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (4,14,'N','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (4,15,'N','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (5,16,'Y','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (5,17,'N','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (5,18,'N','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (5,19,'N','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (5,20,'N','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (5,21,'N','SYSTEM');
INSERT INTO ORGANIZATION_MEMBER (ORGANIZATION_id, PERSON_id, org_leader_in, created_by_user_nm) VALUES (6,21,'Y','SYSTEM');

-- User Account Data
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('PROFESSOR',md5('professor'),1,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT1',md5('student1'),2,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT2',md5('student2'),3,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT3',md5('student3'),4,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT4',md5('student4'),5,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT5',md5('student5'),6,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT6',md5('student6'),7,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT7',md5('student7'),8,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT8',md5('student8'),9,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT9',md5('student9'),10,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT10',md5('student10'),11,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT11',md5('student11'),12,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT12',md5('student12'),13,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT13',md5('student13'),14,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT14',md5('student14'),15,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT15',md5('student15'),16,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT16',md5('student16'),17,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT17',md5('student17'),18,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT18',md5('student18'),19,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT19',md5('student19'),20,'question?','answer');
INSERT INTO USER_ACCOUNT (user_nm, password_tx, PERSON_id, security_question_tx, security_question_response_tx) VALUES ('STUDENT20',md5('student20'),21,'question?','answer');

-- Priority Lookup
INSERT INTO PRIORITY_LOOKUP (priority_nr, priority_description_tx, created_by_user_nm) VALUES (1,'High Priority','SYSTEM');
INSERT INTO PRIORITY_LOOKUP (priority_nr, priority_description_tx, created_by_user_nm) VALUES (2,'Medium Priority','SYSTEM');
INSERT INTO PRIORITY_LOOKUP (priority_nr, priority_description_tx, created_by_user_nm) VALUES (3,'Low Priority','SYSTEM');

-- Comment Type Lookup
INSERT INTO COMMENT_TYPE_LOOKUP (comment_type_tx, comment_type_desc_tx, created_by_user_nm) VALUES ('User Comment','Comment entered by a user','SYSTEM');
INSERT INTO COMMENT_TYPE_LOOKUP (comment_type_tx, comment_type_desc_tx, created_by_user_nm) VALUES ('Task Reassignment','Comment generated by the system when a task is reassigned','SYSTEM');
INSERT INTO COMMENT_TYPE_LOOKUP (comment_type_tx, comment_type_desc_tx, created_by_user_nm) VALUES ('Parent Task Deletion','Comment generated by the system when a parent task is deleted','SYSTEM');
INSERT INTO COMMENT_TYPE_LOOKUP (comment_type_tx, comment_type_desc_tx, created_by_user_nm) VALUES ('Task Created','Comment generated by the system whan a task is created','SYSTEM');


