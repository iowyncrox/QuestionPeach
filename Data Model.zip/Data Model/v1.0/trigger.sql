USE `TASK_MANAGER`;

DELIMITER $$

USE `TASK_MANAGER`$$
DROP TRIGGER IF EXISTS `bdfer_person_check_account` $$
USE `TASK_MANAGER`$$


CREATE TRIGGER bdfer_person_check_account
BEFORE DELETE ON PERSON
FOR EACH ROW
BEGIN
    UPDATE user_account
    SET person_id = NULL
       ,end_dt = NOW()
    WHERE person_id = OLD.person_id;
END;$$


DELIMITER ;

DELIMITER $$

USE `TASK_MANAGER`$$
DROP TRIGGER IF EXISTS `bifer_user_account` $$
USE `TASK_MANAGER`$$


CREATE TRIGGER bifer_user_account
BEFORE INSERT ON USER_ACCOUNT
FOR EACH ROW
BEGIN
    -- If no person id is provided, then disable the account
    IF NEW.person_id IS NULL THEN
        SET NEW.end_dt = NOW();
    END IF;

    -- Force the user_nm to upper case
    SET NEW.user_nm = UCASE(NEW.user_nm);

END$$


USE `TASK_MANAGER`$$
DROP TRIGGER IF EXISTS `bufer_user_account` $$
USE `TASK_MANAGER`$$


CREATE TRIGGER bufer_user_account
BEFORE UPDATE ON USER_ACCOUNT
FOR EACH ROW
BEGIN
    -- If person_id is being set to NULL, then disable the account
    IF NEW.person_id IS NULL THEN
        SET NEW.end_dt = NOW();
    END IF;

    -- Force the user_nm to upper case
    SET NEW.user_nm = UCASE(NEW.user_nm);

END$$


DELIMITER ;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
