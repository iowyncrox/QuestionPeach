/*  These changes include:
    1. Do not allow a person's email address to be null.  Before applying this change, force all NULL values to be unknown@user.com
    2. Create new table USER_INTERFACE_MEMORY
    3. Add before-insert and before-update triggers for the following tables to force the user name fields to upper case
        COMMENT_TYPE_LOOKUP, ORGANIZATION, ORGANIZATION_MEMBER, PERSON, PRIORITY_LOOKUP, TASK, TASK_COMMENT, USER_INTERFACE_MEMORY
       Before applying this change, force all user name values to be in upper case
*/

USE task_manager;

/* 1. Do not allow a person's email address to be null. */
-- Force any existing email values to be not null
UPDATE PERSON
SET email_address_tx = 'unknown@user.com'
WHERE email_address_tx IS NULL;

-- Alter the table to not accept nulls in email_address_tx
ALTER TABLE PERSON
MODIFY EMAIL_ADDRESS_TX VARCHAR(100) NOT NULL;

/* 2. Create new table USER_INTERFACE_MEMORY */
CREATE TABLE IF NOT EXISTS TASK_MANAGER.USER_INTERFACE_MEMORY 
    (USER_NM VARCHAR(30) NOT NULL 
    ,FACT_NM VARCHAR(100) NOT NULL 
    ,FACT_VALUE_TX VARCHAR(100) NOT NULL 
    ,CREATED_DTTM TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(), 
    PRIMARY KEY (USER_NM, FACT_NM) 
    ,INDEX FK_UI_MEMORY_USER_ACCOUNT (USER_NM ASC) 
    ,CONSTRAINT FK_UI_MEMORY_USER_ACCOUNT
        FOREIGN KEY (USER_NM)
        REFERENCES TASK_MANAGER.USER_ACCOUNT (USER_NM)
        ON DELETE RESTRICT
        ON UPDATE CASCADE)
ENGINE = InnoDB;


/* 3. Add before-insert and before-update triggers to force the user name fields to be upper case */

-- Trigger DDL Statements
DELIMITER $$

CREATE TRIGGER bifer_ui_memory
BEFORE INSERT ON USER_INTERFACE_MEMORY
FOR EACH ROW
BEGIN

    -- Force the user_nm to upper case
    SET NEW.user_nm = UCASE(NEW.user_nm);
    
END$$

CREATE TRIGGER bufer_ui_memory
BEFORE UPDATE ON USER_INTERFACE_MEMORY
FOR EACH ROW
BEGIN

    -- Force user_nm to upper case
    SET NEW.user_nm = UCASE(NEW.user_nm);

END$$

CREATE TRIGGER task_manager.bifer_comment_type_lookup
BEFORE INSERT ON task_manager.comment_type_lookup
FOR EACH ROW
BEGIN
	-- Force the user_nm to upper case
	SET NEW.CREATED_BY_USER_NM = UCASE(NEW.CREATED_BY_USER_NM);
	SET NEW.LAST_UPDATED_BY_USER_NM = UCASE(NEW.LAST_UPDATED_BY_USER_NM);

END$$

CREATE TRIGGER task_manager.bufer_comment_type_lookup
BEFORE UPDATE ON task_manager.comment_type_lookup
FOR EACH ROW
BEGIN
	-- Force the user_nm to upper case
	SET NEW.CREATED_BY_USER_NM = UCASE(NEW.CREATED_BY_USER_NM);
	SET NEW.LAST_UPDATED_BY_USER_NM = UCASE(NEW.LAST_UPDATED_BY_USER_NM);

END$$

CREATE TRIGGER task_manager.bifer_organization
BEFORE INSERT ON task_manager.organization
FOR EACH ROW
BEGIN
	-- Force the user_nm to upper case
	SET NEW.CREATED_BY_USER_NM = UCASE(NEW.CREATED_BY_USER_NM);
	SET NEW.LAST_UPDATED_BY_USER_NM = UCASE(NEW.LAST_UPDATED_BY_USER_NM);

END$$

CREATE TRIGGER task_manager.bufer_organization
BEFORE UPDATE ON task_manager.organization
FOR EACH ROW
BEGIN
	-- Force the user_nm to upper case
	SET NEW.CREATED_BY_USER_NM = UCASE(NEW.CREATED_BY_USER_NM);
	SET NEW.LAST_UPDATED_BY_USER_NM = UCASE(NEW.LAST_UPDATED_BY_USER_NM);

END$$

CREATE TRIGGER task_manager.bifer_organization_member
BEFORE INSERT ON task_manager.organization_member
FOR EACH ROW
BEGIN
	-- Force the user_nm to upper case
	SET NEW.CREATED_BY_USER_NM = UCASE(NEW.CREATED_BY_USER_NM);
	SET NEW.LAST_UPDATED_BY_USER_NM = UCASE(NEW.LAST_UPDATED_BY_USER_NM);

END$$

CREATE TRIGGER task_manager.bufer_organization_member
BEFORE UPDATE ON task_manager.organization_member
FOR EACH ROW
BEGIN
	-- Force the user_nm to upper case
	SET NEW.CREATED_BY_USER_NM = UCASE(NEW.CREATED_BY_USER_NM);
	SET NEW.LAST_UPDATED_BY_USER_NM = UCASE(NEW.LAST_UPDATED_BY_USER_NM);

END$$

CREATE TRIGGER task_manager.bifer_person
BEFORE INSERT ON task_manager.person
FOR EACH ROW
BEGIN
	-- Force the user_nm to upper case
	SET NEW.CREATED_BY_USER_NM = UCASE(NEW.CREATED_BY_USER_NM);
	SET NEW.LAST_UPDATED_BY_USER_NM = UCASE(NEW.LAST_UPDATED_BY_USER_NM);

END$$

CREATE TRIGGER task_manager.bufer_person
BEFORE UPDATE ON task_manager.person
FOR EACH ROW
BEGIN
	-- Force the user_nm to upper case
	SET NEW.CREATED_BY_USER_NM = UCASE(NEW.CREATED_BY_USER_NM);
	SET NEW.LAST_UPDATED_BY_USER_NM = UCASE(NEW.LAST_UPDATED_BY_USER_NM);

END$$

CREATE TRIGGER task_manager.bifer_priority_lookup
BEFORE INSERT ON task_manager.priority_lookup
FOR EACH ROW
BEGIN
	-- Force the user_nm to upper case
	SET NEW.CREATED_BY_USER_NM = UCASE(NEW.CREATED_BY_USER_NM);
  SET NEW.LAST_UPDATED_BY_USER_NM = UCASE(NEW.LAST_UPDATED_BY_USER_NM);

END$$

CREATE TRIGGER task_manager.bufer_priority_lookup
BEFORE UPDATE ON task_manager.priority_lookup
FOR EACH ROW
BEGIN
	-- Force the user_nm to upper case
	SET NEW.CREATED_BY_USER_NM = UCASE(NEW.CREATED_BY_USER_NM);
  SET NEW.LAST_UPDATED_BY_USER_NM = UCASE(NEW.LAST_UPDATED_BY_USER_NM);

END$$

CREATE TRIGGER task_manager.bifer_task
BEFORE INSERT ON task_manager.task
FOR EACH ROW
BEGIN
	-- Force the user_nm to upper case
	SET NEW.CREATED_BY_USER_NM = UCASE(NEW.CREATED_BY_USER_NM);
	SET NEW.LAST_UPDATED_BY_USER_NM = UCASE(NEW.LAST_UPDATED_BY_USER_NM);

END$$

CREATE TRIGGER task_manager.bufer_task
BEFORE UPDATE ON task_manager.task
FOR EACH ROW
BEGIN
	-- Force the user_nm to upper case
	SET NEW.CREATED_BY_USER_NM = UCASE(NEW.CREATED_BY_USER_NM);
	SET NEW.LAST_UPDATED_BY_USER_NM = UCASE(NEW.LAST_UPDATED_BY_USER_NM);

END$$

CREATE TRIGGER task_manager.bifer_task_comment
BEFORE INSERT ON task_manager.task_comment
FOR EACH ROW
BEGIN
	-- Force the user_nm to upper case
	SET NEW.CREATED_BY_USER_NM = UCASE(NEW.CREATED_BY_USER_NM);

END$$

CREATE TRIGGER task_manager.bufer_task_comment
BEFORE UPDATE ON task_manager.task_comment
FOR EACH ROW
BEGIN
	-- Force the user_nm to upper case
	SET NEW.CREATED_BY_USER_NM = UCASE(NEW.CREATED_BY_USER_NM);
	
END$$

DELIMITER ;

-- Force existing created by user name and last updated by user name values to upper case
-- COMMENT_TYPE_LOOKUP
UPDATE COMMENT_TYPE_LOOKUP
SET created_by_user_nm = UCASE(created_by_user_nm)
   ,last_updated_by_user_nm = UCASE(last_updated_by_user_nm);

-- ORGANIZATION
UPDATE ORGANIZATION
SET created_by_user_nm = UCASE(created_by_user_nm)
   ,last_updated_by_user_nm = UCASE(last_updated_by_user_nm);
   
-- ORGANIZATION_MEMBER
UPDATE ORGANIZATION_MEMBER
SET created_by_user_nm = UCASE(created_by_user_nm)
   ,last_updated_by_user_nm = UCASE(last_updated_by_user_nm);
   
-- PERSON
UPDATE PERSON
SET created_by_user_nm = UCASE(created_by_user_nm)
   ,last_updated_by_user_nm = UCASE(last_updated_by_user_nm);
   
-- PRIORITY_LOOKUP
UPDATE PRIORITY_LOOKUP 
SET created_by_user_nm = UCASE(created_by_user_nm)
   ,last_updated_by_user_nm = UCASE(last_updated_by_user_nm);
   
-- TASK
UPDATE TASK
SET created_by_user_nm = UCASE(created_by_user_nm)
   ,last_updated_by_user_nm = UCASE(last_updated_by_user_nm);

-- TASK_COMMENT
/*
UPDATE TASK_COMMENT
SET created_by_user_nm = UCASE(created_by_user_nm)
   ,last_updated_by_user_nm = UCASE(last_updated_by_user_nm);
*/

UPDATE task_comment
SET created_by_user_nm = UCASE(created_by_user_nm);
  
-- USER_INTERFACE_MEMORY
/*
UPDATE user_interface_memory
SET created_by_user_nm = UCASE(created_by_user_nm)
   ,last_updated_by_user_nm = UCASE(last_updated_by_user_nm);
*/

UPDATE user_interface_memory
SET user_nm = UCASE(user_nm);