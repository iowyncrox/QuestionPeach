-- Drop get_assign_to_people.  It will be recreated below.
DROP PROCEDURE IF EXISTS get_assign_to_people;
DROP PROCEDURE IF EXISTS get_org_children;
DROP PROCEDURE IF EXISTS get_visible_orgs;
DROP PROCEDURE IF EXISTS remove_task;

DELIMITER $$

-- Modify procedure to remove the restriction that a person cannot assign to a leader unless he/she is a leader
CREATE PROCEDURE get_assign_to_people
    (p_username VARCHAR(30)
    ,p_org_id   INT)
BEGIN
    
    -- Find the organizations this user can see
    CALL get_visible_orgs(p_username);
            
    -- Select the results
    SELECT DISTINCT p.person_id
          ,CONCAT(p.first_nm,' ',p.last_nm) person_nm
    FROM __org_list ol
    JOIN organization_member om
      ON ol.organization_id = om.organization_id
    JOIN person p
      ON om.person_id = p.person_id
    WHERE IFNULL(p_org_id,ol.organization_id) = ol.organization_id
 /* -- 2012-04-22: Modified this query to allow the person to assign to any other person in organizations he/she can view
    --   There is no longer a restriction that he/she cannot assign to a leader unless he/she is a leader
    AND (-- Cannot assign to an organization leader unless this user is an organization leader
            ol.organization_leader_in = 'Y'
         OR om.org_leader_in <> 'Y') */
    ORDER BY person_nm;
    
END$$

-- Modify procedure, because it no longer needs to capture if a person is a leader in the organization
CREATE PROCEDURE get_org_children 
    (p_parent_org_id   INT
/*    2012-04-22: This procedure no longer needs to capture if the user is a leader in the organization
    ,p_org_leader_in   CHAR(1)*/)
BEGIN
    -- Declare variables
    -- Holds child's organization id
    DECLARE v_child_org_id INT;
    -- Indicates if there are no more records in the cursor
    DECLARE v_done INT DEFAULT 0;
    -- Cursor to find the child organizations to p_parent_org_id
    DECLARE org_curs CURSOR FOR 
        SELECT organization_id
        FROM organization
        WHERE parent_organization_id = p_parent_org_id;
    -- Handler to tell when no more records retrieved by cursor --> exit the loop
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = 1;
    
    -- Find child organizations for the p_org_id
    OPEN org_curs;
    
    -- Loop through records retrieved
    get_child_fetch_loop: LOOP
        FETCH org_curs INTO v_child_org_id;
        
        -- If the cursor retrieved nothing, v_done gets set to 1 by the handler
        IF v_done = 1 THEN
            LEAVE get_child_fetch_loop;
        END IF;
        
        -- Insert the child organization into the temporary table
        INSERT INTO __org_list_build VALUES (v_child_org_id
        /*2012-04-22: Changed to no longer capture if the person is a leader in the organization
        , p_org_leader_in*/);
        
        -- Recursively call this procedure again for the child that is found
        CALL get_org_children(v_child_org_id
        /*2012-04-22: Changed to no longer capture if the person is a leader in the organization
        , p_org_leader_in*/);
        
    END LOOP get_child_fetch_loop;
    
    -- Close the cursor
    CLOSE org_curs;
        
END$$

-- Modify procedure, because it no longer needs to capture if a person is a leader in the organization
CREATE PROCEDURE get_visible_orgs
    (p_username VARCHAR(30))
BEGIN

    -- Declare variables
    DECLARE v_org_id, v_build_ct INT;
    -- Holds parent organization ID
    DECLARE v_parent_org_id INT DEFAULT -1;
    -- Indicates if there are no more records in the cursor
    DECLARE v_done INT DEFAULT 0; 
    -- Cursor to find the organizations this user belongs to
    DECLARE org_member_curs CURSOR FOR
        SELECT om.organization_id
              /* 2012-04-22: Changed to no longer capture if the person is a leader in the organization
              ,om.org_leader_in*/
        FROM user_account ua
        JOIN person p
          ON ua.person_id = p.person_id
        JOIN organization_member om
          ON p.person_id = om.person_id
        WHERE ua.user_nm = UCASE(p_username);
    -- Handler to tell when no more records retrieved by org_member_curs --> exit the loop
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = 1;
    /* 2012-04-22: Changed to no longer capture if the person is a leader in the organization
    DECLARE v_org_leader_in CHAR(1);*/

    -- Create a temporary tables to store the org ids the user can access
    -- __org_list_build is the working copy
    -- __org_list is the final copy
    DROP TEMPORARY TABLE IF EXISTS __org_list_build;
    CREATE TEMPORARY TABLE __org_list_build
        (organization_id INT NOT NULL PRIMARY KEY
        /* 2012-04-22: Changed to no longer capture if the person is a leader in the organization
        ,organization_leader_in CHAR(1) NOT NULL DEFAULT 'N'*/);
    DROP TEMPORARY TABLE IF EXISTS __org_list;
    CREATE TEMPORARY TABLE __org_list 
        (organization_id INT NOT NULL PRIMARY KEY
        /* 2012-04-22: Changed to no longer capture if the person is a leader in the organization
        ,organization_leader_in CHAR(1) NOT NULL DEFAULT 'N'*/);
            
    -- Find organizations the user belongs to
    OPEN org_member_curs;
    
    -- Loop through organizations
    get_org_fetch_loop: LOOP
    
        FETCH org_member_curs INTO v_org_id;

        -- If the cursor retrieved nothing, v_done gets set to 1 by the handler
        IF v_done = 1 THEN
            LEAVE get_org_fetch_loop;
        END IF;
        
        -- Find the top-most parent in the organization
        -- Loop through parent organizations until parent is NULL
        get_parent_loop: LOOP
        
            -- Once the parent_org_id is null then leave the loop
            IF v_parent_org_id IS NULL THEN
                LEAVE get_parent_loop;
            ELSE
                -- Set the current organization to be the parent of the last iteration unless this is the first time through 
                -- v_parent_org_id defaults to -1
                IF v_parent_org_id <> -1 THEN
                    SET v_org_id = v_parent_org_id;
                END IF;
                
            END IF;
            
            -- Get the current organization's parent
            SELECT parent_organization_id
            INTO v_parent_org_id
            FROM organization
            WHERE organization_id = v_org_id;
        
        END LOOP get_parent_loop;

        -- Add the organization to __org_list_build if it isn't already there
        SELECT COUNT(1)
        INTO v_build_ct
        FROM __org_list_build
        WHERE organization_id = v_org_id;
        
        IF v_build_ct = 0 THEN
            INSERT INTO __org_list_build VALUES (v_org_id);
            CALL get_org_children(v_org_id);
        END IF;

        /* 
        -- Old loop to find the child organizations of the user's member organization
        FETCH org_member_curs INTO v_org_id, v_org_leader_in;
        
        -- If the cursor retrieved nothing, v_done gets set to 1 by the handler
        IF v_done = 1 THEN
            LEAVE get_org_fetch_loop;
        END IF;
        
        -- Insert the organization into the temporary table
        INSERT INTO __org_list_build VALUES (v_org_id, v_org_leader_in);

        -- Find children for these organizations
        CALL get_org_children(v_org_id, v_org_leader_in);
        
        -- End old code 
        */
    
    -- End loop
    END LOOP get_org_fetch_loop;

    -- Close the cursor
    CLOSE org_member_curs;
    
    -- 2012-04-22: Added distinct, removed MAX(organization_leader_in), removed GROUP BY
    -- Insert into the final table
    INSERT INTO __org_list
    SELECT DISTINCT organization_id-- , MAX(organization_leader_in)
    FROM __org_list_build
    -- GROUP BY organization_id
    ;
    
    -- Drop the interim table 
    DROP TEMPORARY TABLE IF EXISTS __org_list_build;
	
END$$

-- Fix bug in call to add_task_comment: should have used p_del_task_id instead of p_task_id
CREATE PROCEDURE remove_task    
    (p_del_task_id INT
    ,p_username VARCHAR(30))
BEGIN

    DECLARE v_dummy INT;
    DECLARE v_parent_task_id, v_child_task_id INT;
    DECLARE v_deleted_short_title_tx, v_parent_short_title_tx VARCHAR(50); 
        
    -- Find the parent task of the task we want to delete
    SELECT ct.parent_task_id, ct.short_title_tx, pt.short_title_tx 
    INTO v_parent_task_id, v_deleted_short_title_tx, v_parent_short_title_tx
    FROM task ct
    LEFT JOIN task pt
      ON  ct.parent_task_id = pt.task_id  
    WHERE ct.task_id = p_del_task_id;
    
    -- If there is a parent task
    IF v_parent_task_id IS NOT NULL THEN
    
        -- Log a comment on the parent task that one of its children was deleted
        CALL add_task_comment
            (p_del_task_id
            ,CONCAT('Subtask "', v_deleted_short_title_tx, '" has been deleted.')
            ,'Child Task Deletion'
            ,p_username);
        
        -- Log a comment on the deleted task's children (if any) that their parent is changing.  It will be the delete task's parent
        INSERT INTO task_comment
                (task_id
                ,comment_tx
                ,comment_type_tx
                ,created_by_user_nm)
        SELECT task_id
              ,CONCAT('Parent Task "', v_deleted_short_title_tx, '" was deleted and new Parent Task is "', v_parent_short_title_tx,'".')
              ,'Parent Task Deletion'
              ,p_username
        FROM task WHERE parent_task_id = p_del_task_id;
                   
    ELSE
       
         -- log a comment with the assignment information
        CALL add_task_comment
            (p_del_task_id
            ,CONCAT('Parent Task "', v_deleted_short_title_tx, '" was deleted.')
            ,'Parent Task Deletion'
            ,p_username);  
       
    END IF;
       
    -- Set the deleted task's child tasks to use the deleted task's parent as their parent
    UPDATE task
    SET parent_task_id = v_parent_task_id
      ,last_updated_by_user_nm = p_username
      ,last_updated_dttm = current_timestamp
    WHERE parent_task_id = p_del_task_id;
       
    -- Actually delete the task
    DELETE FROM task
    WHERE task_id = p_del_task_id;
    
END$$

