<?php

// Check that file was called from WordPress admin
if (!defined('WP_UNINSTALL_PLUGIN'))
    exit();

builder_drop_table();

function builder_drop_table() {


/*
global $wpdb;
    $wpdb->query("Drop Table gwu_response");
    $wpdb->query("Drop Table gwu_session");
    $wpdb->query("Drop Table gwu_flag");
    $wpdb->query("Drop Table gwu_answerChoice");
    $wpdb->query("Drop Table gwu_action");
    $wpdb->query("Drop Table gwu_condition");
    $wpdb->query("Drop Table gwu_question");
    $wpdb->query("Drop Table gwu_questionnaire");
    $wpdb->query("Drop Table gwu_answerChoice");
    $wpdb->query("Drop Table gwu_question");
    $wpdb->query("Drop Table gwu_questionnaire");
*/
}

?>
