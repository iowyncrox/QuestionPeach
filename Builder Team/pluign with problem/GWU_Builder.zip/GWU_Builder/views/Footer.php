<?php
//footer can have some usful line later for know, it close some tags
?>
 <script type="text/javascript"  src=<?php echo WP_PLUGIN_URL . '/GWU_Builder/images/QuestionForm.js' ?> ></script>
      <link rel="stylesheet" type="text/css" href=<?php echo WP_PLUGIN_URL . '/GWU_Builder/images/pureStyle.css' ?> media="screen" />
