This is what you will need to do in order to open the Report page in Flex:

1. Download and extract the zip file into a suitable location in your computer; preferably into your workspace.
2. Make sure the .fxp file is in your default workspace (or change your defauld work space)
3. In Flex Builder click File>Import
4. Select Flash Builder>Flash Builder Project in the dialog box
5. Next and Select File (radio)
6. Browse to where your extracted .fxp file is located
7. Click Open, and then Next
8. Update your path variable and Finish
9. In Flex, you have a DataGrid showing the various headings we would like to display and sort by.

Sorting can be achieved by clicking on the little arrow head that will be located on the header buttons.

We are still working on that, and hope to accomplish this in the next review.

Note that data can be populated in this table via the PHP code after connecting onto the database.