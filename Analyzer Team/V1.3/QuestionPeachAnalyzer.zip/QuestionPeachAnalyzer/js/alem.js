<!--**************AJAX Function*********************-->
		<script>
		
		
			function reload(form)
			{
				var question = form.question.options[form.question.options.selectedIndex].value;
				var val=form.questionnaire.options[form.questionnaire.options.selectedIndex].value;
				if(question){
					self.location='/questionpeach-analyzer-gui/?questionnaire=' + val +'&question='+ question;
				} else {
					self.location='/questionpeach-analyzer-gui/?questionnaire=' + val;
				}
			}
		
		
			function getXMLHTTP() { //fuction to return the xml http object
				var xmlhttp=false;
				try{
					xmlhttp=new XMLHttpRequest();
				}
				catch(e)	{
					try{
						xmlhttp= new ActiveXObject("Microsoft.XMLHTTP");
					}
					catch(e){
						try{
							xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
						}
						catch(e1){
							xmlhttp=false;
						}
					}
				}
		
				return xmlhttp;
			}
		
			function getQuestion(strURL){
				getFilter(strURL);
				getDetail(strURL)
			}
			function getFilter (strURL) {
		
				var req = getXMLHTTP();
		
				if (req) {
		
					req.onreadystatechange = function() {
						if (req.readyState == 4) {
							// only if "OK"
							if (req.status == 200) {
								document.getElementById('Questiondiv').innerHTML=req.responseText;
							} else {
								alert("There was a problem while using XMLHTTP:\n" + req.statusText);
							}
						}
					}
					req.open("GET", strURL, true);
					req.send(null);
				}
		
			}
		
			function getDetail (strURL) {
				var newURL = strURL.replace("findQuestionnair","detail");
				var req = getXMLHTTP();
		
				if (req) {
		
					req.onreadystatechange = function() {
						if (req.readyState == 4) {
							// only if "OK"
							if (req.status == 200) {
								document.getElementById('Detaildiv').innerHTML=req.responseText;
							} else {
								alert("There was a problem while using XMLHTTP:\n" + req.statusText);
							}
						}
					}
					req.open("GET", newURL, true);
					req.send(null);
				}
		
			}
			function getResult(strURL) {
		
				var req = getXMLHTTP();
		
				if (req) {
		
					req.onreadystatechange = function() {
						if (req.readyState == 4) {
							// only if "OK"
							if (req.status == 200) {
								document.getElementById('resultdiv').innerHTML=req.responseText;
							} else {
								alert("There was a problem while using XMLHTTP:\n" + req.statusText);
							}
						}
					}
					req.open("GET", strURL, true);
					req.send(null);
				}
		
			}
		
		
		</script>