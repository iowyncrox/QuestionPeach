<table>
	<tr class="tr">
	<td class="td" colspan="4">
	<div id="chart_div" style="width: 400px; height: 222px; margin:0 auto;"></div>
	</td>
	</tr>
	<tr class="tr">
	<td class="td" colspan="4">
	<table class="table">
	<tr class="tr">
		<td class="td"><strong>1. I should financially support my parents when they are old.</strong></td>
	</tr>
	<tr class="tr">
	<td class="td"><img align="middle" src="http://chart.apis.google.com/chart?cht=p3&chs=450x200&chd=t:2,4,3,1&chl=Strongly Agree|Agree|Disagree|Strongly Disagree&chtt=Question%20One&chco=ff0000"/>
  </td></tr>
	</table>
	</td>
	</tr>
	<tbody>
	</table>