<?php
$questionnaire=$_GET['questionnaire'];


include "connection.php";
include ("jpgraph/jpgraph.php");
include ("jpgraph/jpgraph_pie.php");
include ("jpgraph/jpgraph_bar.php");
$dir = plugin_dir_path( __FILE__ );

$msg = '';

$questions = mysql_query("SELECT question_id, topic, title
FROM wp_question_dim A, wp_questionnaire_dim B
WHERE A.questionnaire_id = B.questionnaire_id
AND A.questionnaire_id = $questionnaire");
$survey = mysql_fetch_row($questions);
$msg = $msg.'<h4>'.$survey[1].'</h4><h5>'.$survey[2].'</h5>';
if(mysql_num_rows($questions) > 0){
	while($question = mysql_fetch_assoc($questions)) {

		$qid = $question['question_id'];
		
		// For The Questionnaire information
		$result = mysql_query("SELECT question_id, questionnaire_id, question_text, ans_type, response_content, COUNT( * ) AS total
		FROM wp_question_dim Q, wp_question_response QR
		WHERE questionnaire_id = $questionnaire
		AND question_id = $qid
		AND QR.questionnaire_dim_questionnaire_id = Q.questionnaire_id
		AND QR.question_dim_question_id = Q.question_id
		GROUP BY response_content");
		if(mysql_num_rows($result) > 0){

			$row = mysql_fetch_row($result);
			$text = '<ul>';
			// if the answer type is text
			if($row['ans_type']=='Text Box'){
				while($rows = mysql_fetch_assoc($result)) {
					$text = $text.'<li>'.$rows['response_content'].'</li>';
				}
				$text = $text.'</ul>';
				$msg =$msg.'<table class="table">
				<tbody>
				<tr class="tr">
				<td colspan="4" class="td">'.$row[0].'. '.$row[2].'</td>
				</tr>
				<tr class="tr">
				<td colspan="4" class="td">'.$text.'</td>
				</tr>
				</tbody>
				</table>';
			} else{
				$key = array();
				$value = array();
				while($rows = mysql_fetch_assoc($result)) {
					$key[] = $rows['response_content'];
					$value[] = $rows['total'];
				}


				//graph


				// Create the graph. These two calls are always required
				$graph = new Graph(600,600,'auto');
				$graph->SetScale("textlin");

				//$theme_class="DefaultTheme";
				//$graph->SetTheme(new $theme_class());

				// set major and minor tick positions manually


				//$graph->ygrid->SetColor('gray');
				$graph->ygrid->SetFill(false);
				$graph->xaxis->SetTickLabels($key);
				$graph->xaxis->SetLabelAngle(50);
				$graph->yaxis->HideLine(false);
				$graph->yaxis->HideTicks(false,false);

				// Create the bar plots
				$b1plot = new BarPlot($value);

				// ...and add it to the graPH
				$graph->Add($b1plot);


				$b1plot->SetColor("white");
				$b1plot->SetFillGradient("#4B0082","white",GRAD_LEFT_REFLECTION);
				$b1plot->SetWidth(45);
				//$graph->title->Set($row[2]);

				// Display the graph
				$graph->Stroke($dir.'chart'.$qid.'.png');
				$url =  plugins_url( 'chart'.$qid.'.png' , __FILE__ );

				$msg =$msg.'<table class="table">
				<tbody>
				<tr class="tr">
				<td colspan="4" class="td">'.$row[0].'. '.$row[2].'</td>
				</tr>
				<tr class="tr">
				<td colspan="4" class="td">
				<img align="center" src="/wp-content/plugins/QuestionPeachAnalyzer/chart'.$qid.'.png" >
				</td>
				</tr>
				</tbody>
				</table>';
			}



		} else {

			$msg = $msg.'<table class="table">
			<tbody>
			<tr class="tr">
			<td colspan="4" class="td">There is no result available for this question</td>
			</tr></tr>
			</tbody>
			</table>';
		}
	}
}


echo $msg;
?>