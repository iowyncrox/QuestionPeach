<?php
/*
Plugin Name: Analyzer
Plugin URI: http://localhost/wordpress
Description: Week_3 test plugin is designed to create and/or drop the Analyzer table, Schedule cron jobs and migrate data 
Version: 1.0
Author: Analyzer Team
Author URI: http://localhost/wordpress
*/
global $msg;
global $analyzer_tbls;

////////////////////////// Plugin shortcode ////////////////////////////////
add_shortcode('analyzer_create_shtz', function(){
 return analyzer_create_tbl();
});

add_shortcode('analyzer_drop_shtzXX', function(){
 return analyzer_drop_tbl();
});

add_shortcode('analyzer_migrate_builder_data_shtz', function(){
 return analyzer_migrate_builder_data();
});
 
add_shortcode('analyzer_cron_job_actv_shtz', function(){
 analyzer_cron_job_activation();
 return true;
});

add_shortcode('analyzer_cron_job_deactv_shtz', function(){
 analyzer_cron_job_deactivation();
 return true;
});



add_shortcode('rpt', function(){

 return analyzer_show_tbls();
});
 
/////////////////////////////analyzer_create_tbl///////////////////
function analyzer_create_tbl() 
{
 require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
 global $wpdb;
 $analyzer_tbls= array('wp_respondee_dim', 'wp_time_dim', 'wp_question_dim', 'wp_location_dim', 'wp_questionnaire_dim','wp_question_response');

 $msg.="<h4> 1. Verifying if table the following tables exist:</h4><br> ".loop_arr($analyzer_tbls);
 
 if( $wpdb->get_var( "SHOW TABLES LIKE '".$analyzer_tbls[0]."'" ) != $analyzer_tbls[0] ) 
 {
  $msg.="<h4>2. Now creating tables </h4><i>".loop_arr($analyzer_tbls)."</i>";
  
  $sql = "CREATE TABLE wp_respondee_dim (
  respondee_id INTEGER UNSIGNED NOT NULL,
  survey_completed BOOL NULL,
  survey_taken_date DATE NULL,
  username VARCHAR(100) NULL,
  ip VARCHAR(20) NULL,
  duration TIME NULL,
  PRIMARY KEY(respondee_id)
);

CREATE TABLE wp_time_dim (
  time_id BIGINT NOT NULL,
  date DATE NOT NULL,
  day_2 CHAR(10) NULL,
  day_of_week INT NULL,
  day_of_month INT NULL,
  day_of_year INT NULL,
  weekend CHAR(10) NOT NULL DEFAULT 'Weekday',
  week_of_year CHAR(2) NULL,
  month_3 CHAR(10) NULL,
  month_of_year CHAR(2) NULL,
  quarter_of_year INT NULL,
  year_3 INT NULL,
  PRIMARY KEY(time_id),
  UNIQUE INDEX time_dim_uniq(date)
);

CREATE TABLE wp_question_dim (
  question_id INTEGER UNSIGNED NOT NULL,
  questionnaire_id INTEGER(20) UNSIGNED NOT NULL,
  question_text TEXT NULL,
  ans_type VARCHAR(100) NULL,
  PRIMARY KEY(question_id, questionnaire_id)
);

CREATE TABLE wp_location_dim (
  location_id INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  city VARCHAR(50) NULL,
  country VARCHAR(50) NULL,
  PRIMARY KEY(location_id)
);

CREATE TABLE wp_questionnaire_dim (
  questionnaire_id INTEGER(20) UNSIGNED NOT NULL,
  topic VARCHAR(100) NULL,
  date_created DATE NULL,
  allow_anonymous BOOL NULL,
  allow_multiple BOOL NULL,
  title VARCHAR(100) NULL,
  creator_name VARCHAR(100) NULL,
  PRIMARY KEY(questionnaire_id)
);

CREATE TABLE wp_question_response (
  response_id int(10) unsigned NOT NULL,
  question_dim_questionnaire_id int(20) unsigned NOT NULL,
  question_dim_question_id int(10) unsigned NOT NULL,
  time_dim_time_id bigint(20) DEFAULT NULL,
  respondee_dim_respondee_id int(10) unsigned NOT NULL,
  questionnaire_dim_questionnaire_id int(20) unsigned NOT NULL,
  location_dim_location_id int(10) unsigned DEFAULT NULL,
  response_content text,
  response_type varchar(100) DEFAULT NULL,
  PRIMARY KEY (response_id)
);
$charset_collate;";
  
  dbDelta( $sql );
  
  $msg.="<h4><br>Successfully created the following tables: <br></h4>".loop_arr($analyzer_tbls);
 }
 else
 {
  $msg.="<h4>2. Tables:<br></h4> ".loop_arr($analyzer_tbls)."<h4><br> already exist</h4>";
 }
  $msg.=analyzer_show_tbls();
 return $msg;
}

/////////////////////////////analyzer_drop_tbl///////////////////
function analyzer_drop_tbl() 
{
 $analyzer_tbls= array('wp_respondee_dim', 'wp_time_dim', 'wp_question_dim', 'wp_location_dim', 'wp_questionnaire_dim','wp_question_response');

 $msg=loop_arr($analyzer_tbls);
 require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
 global $wpdb;

 $msg.="<h4>1. Verifying if the following tables exist:</h4><br> ".loop_arr($analyzer_tbls);
 $msg.=analyzer_show_tbls();
 
 if($wpdb->get_var( "SHOW TABLES LIKE '".$analyzer_tbls[0]."'" ) == $analyzer_tbls[0])  
 { 
  $msg.="<h4>2. Now dropping tables </h4><i>".loop_arr($analyzer_tbls)."</i>";
  
  $wpdb->query( 'DROP TABLE IF EXISTS wp_respondee_dim,
				 wp_time_dim,
				 wp_question_dim,
				 wp_location_dim,
				 wp_questionnaire_dim,
				 wp_question_response');
  $msg.="<h4><br>Successfully dropped the following tables:</h4><br>".loop_arr($analyzer_tbls);
 }
 else
 {
  $msg.="<h4>2. Cannot drop tables since they don't exist:</h4><br> ".loop_arr($analyzer_tbls);
 }
 return $msg;
}

/////////////////////////////analyzer_migrate_builder_data///////////////////
function analyzer_migrate_builder_data()
{
 $sql_1="INSERT INTO wp_location_dim (city, country)
         SELECT distinct City, Country
         FROM gwu_session
         WHERE City    NOT IN(select distinct city    from wp_location_dim)
         AND   Country NOT IN(select distinct country from wp_location_dim)";

 $sql_2="INSERT INTO wp_question_dim (question_id, questionnaire_id, question_text, ans_type)
	 SELECT question_number, QuestionnaireID, gwu_question.text, AnsType
	 FROM gwu_question";


 $analyzer_tbls= array('sql_1');

 require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
 global $wpdb;

 $wpdb->query( $sql_1);
 //$wpdb->query( $sql_1);
  
 $wp_ld=analyzer_get_rec_count("select count(*) from wp_location_dim");
 $wp_q=analyzer_get_rec_count("select count(*) from wp_question_dim");
 $wp_qd=analyzer_get_rec_count("select count(*) from wp_questionnaire_dim");
 $wp_r=analyzer_get_rec_count("select count(*) from wp_respondee_dim");
 $wp_rr=analyzer_get_rec_count("select count(*) from wp_question_response");

 $res_tbl.="<div class='wrap'>";
 $res_tbl.="<h3>".$title."</h3>";
 $res_tbl.=" <table>";
 $res_tbl.="  <tr>";
 $res_tbl.="   <th colspan=2>Analyzer tables</th>";
 $res_tbl.="  </tr>";
 $res_tbl.="  <tr>";
 $res_tbl.="   <td>wp_location_dim record </td><td>count: ".$wp_ld."</td>";
 $res_tbl.=" </tr>";
 $res_tbl.="  <tr>";
 $res_tbl.="   <td>wp_questionnaire_dim</td><td>record count: ".$wp_qd."</td>";
 $res_tbl.=" </tr>";
 $res_tbl.="  <tr>";
 $res_tbl.="   <td>wp_respondee_dim</td><td>record count: ".$wp_r."</td>";
 $res_tbl.=" </tr>";
 $res_tbl.="  <tr>";
 $res_tbl.="   <td>wp_question_response</td><td>record count: ".$wp_rr."</td>";
 $res_tbl.=" </tr>";
 $res_tbl.="  <tr>";
 $res_tbl.="   <td>wp_question_dim</td><td>record count: ".$wp_q."</td>";
 $res_tbl.=" </tr>";
 $res_tbl.="  <tr>";
 //$res_tbl.="   <td colspan=2>Mgration Errors:</td><td>".$wpdb->print_error()."</td>";
 $res_tbl.=" </tr>";

 $res_tbl.=" </table>";
 $res_tbl.="<div>";
 
 return $res_tbl;
}

///////////////////////////// analyzer_get_rec_count($qry) ////////////////////////////////////
function analyzer_get_rec_count($qry)
{
 require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
 global $wpdb;

 $cnt= $wpdb->get_var($qry);

 return $cnt;
}


///////////////////////////// analyzer_show_tbls ////////////////////////////////////
function analyzer_show_tbls()
{
 require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
 global $wpdb;
 
 $qry="select TABLE_NAME from INFORMATION_SCHEMA.TABLES 
	   
	   WHERE  table_name LIKE 'wp_%dim' 
	   or  table_name='wp_question_response' ";
 $arr_tbl= $wpdb->get_results($qry);

 $res_tbl.="<div class='wrap'>";
 $res_tbl.="<h3>".$title."</h3>";
 $res_tbl.=" <table>";
 $res_tbl.="  <tr>";
 $res_tbl.="   <th>Analyzer tables</th>";
 $res_tbl.="  </tr>";
 foreach($arr_tbl as $i)
 {
  $res_tbl.="  <tr>";
  $res_tbl.="   <td>".$i->TABLE_NAME."</td>";
  $res_tbl.=" </tr>";
 }
 $res_tbl.=" </table>";
  $res_tbl.="<div>";
 return $res_tbl; 
}
/////////////////////////////analyzer_exec_sql///////////////////
function analyzer_exec_sql($qry, $qry_type) 
{
 require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
 global $wpdb;
 
 $msg.="<br>".$db_table_name;
 $sql_res=null;
 $res_view="";
 if($qry_type=='exec')
 {
  $sql_res = $wpdb->get_results($qry);
 
  $res_view.='<ul>';
  foreach($sql_res as $i) 
  {
   $res_view.='<li>'.$i->emp_id.'</li>';
  }
  $res_view.='</ul>';
  $msg.="<br>".$res_view;
 }
 else if($qry_type=='update')
 {
  $sql_res = $wpdb->query($qry);
  $msg.='<br>'.'table updated';
 }
 
 return $msg;
}	

//////////////////////////////////////// analyzer_cron_job_activation functions ////////////////////////////

function analyzer_cron_job_activation() 
{
 if(!wp_next_scheduled('analyzer_data_migration')) 
 {
  wp_schedule_event(current_time('timestamp'), 'everyminute', 'analyzer_data_migration');
 }
}

function analyzer_task_to_exec()  
{
 return analyzer_exec_sql('INSERT wp_res_2 SELECT * FROM wp_res_1', 'update');
}

/////////////////////////////////// analyzer_cron_job_intervals //////////////////////////////////////////////
function analyzer_cron_job_intervals($schedules) 
{
 $schedules['everyminute'] = array(
									'interval' => 60,
									'display' => __( 'Once Every Minute' )
								  );
 return $schedules;
}

////////////////////////////////////// analyzer_cron_job_deactivation ///////////////////////////////////////////
function analyzer_cron_job_deactivation() 
{
 wp_clear_scheduled_hook('analyzer_data_migration');
}
///////////////////////////////////// analyzer_cron_jobs action hooks //////////////////////////////////////////
//add_action('wp', analyzer_cron_job_activation);
add_filter('cron_schedules', 'analyzer_cron_job_intervals');
add_action ('analyzer_data_migration', 'analyzer_task_to_exec'); 


/////////////////////// register_activation_hooks ////////////////////////////////
register_activation_hook(__FILE__, 'analyzer_create_tbl');
register_deactivation_hook(__FILE__, 'analyzer_drop_tbl');
register_deactivation_hook(__FILE__, 'analyzer_cron_job_deactivation');


/////////////////////////////////// analyzer_utils loop_arr /////////////////////////////////
function loop_arr($arr)
{
 $res='<ul>';
 foreach ($arr as $i) 
 {
  $res.='<li>'.$i .'<li>';
  
 }
 $res.='</ul>';

 return $res;
}

/////////////////////////////////// analyzer_utils loop_arr_tbl /////////////////////////////////
function loop_arr_tbl($arr, $arr_cols, $title)
{
 $res_tbl.="<div class='wrap'>";
 $res_tbl.="<h3>".$title."</h3>";
 $res_tbl.=" <table class='wp-list-table widefat fixed'>";
 $res_tbl.="  <tr>";
 foreach($arr_cols as $i)
 {
  $res_tbl.="   <th>".$i."</th>";
 }
  $res_tbl.="  </tr>";
 foreach($arr as $j)
 {
  $res_tbl.="  <tr>";
  $res_tbl.="   <td>".$j."</td>";
  $res_tbl.=" </tr>";
 }
  $res_tbl.=" </table>";
  $res_tbl.="<div>";
 
 return $res_tbl;
}


?>